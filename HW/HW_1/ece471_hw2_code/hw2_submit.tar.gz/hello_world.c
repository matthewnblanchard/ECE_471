#include <stdio.h>

int main(int argc, char **argv) {

        int i = 0;      // Loop index
        for (i = 1; i <= 20; i++) {
                printf("#%d: ECE471 I can't think of a message\n", i); // Print message numbered by loop index
        }

	return 0;
}
